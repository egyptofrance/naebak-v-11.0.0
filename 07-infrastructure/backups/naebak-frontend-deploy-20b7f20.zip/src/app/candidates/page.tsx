'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface Candidate {
  id: string;
  name: string;
  candidateType: string;
  governorate: string;
  constituency: string;
  party: string;
  electoralSymbol: string;
  electoralNumber: string;
  gender?: string;
  image?: string;
  rating?: number;
}

export default function CandidatesPage() {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [filteredCandidates, setFilteredCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    name: '',
    gender: '',
    governorate: '',
    constituency: '',
    party: '',
    candidateType: '',
    councilType: '' // إضافة فلتر نوع المجلس
  });

  const candidatesPerPage = 15; // 3 rows × 5 cards per row on desktop
  const totalPages = Math.ceil(filteredCandidates.length / candidatesPerPage);

  // Fetch candidates from API
  useEffect(() => {
    fetchCandidates();
    
    // إعادة تحميل البيانات كل 30 ثانية للحصول على المرشحين الجدد
    const interval = setInterval(() => {
      fetchCandidates();
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const fetchCandidates = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/candidates');
      const data = await response.json();
      
      if (data.success) {
        setCandidates(data.candidates);
        setFilteredCandidates(data.candidates);
      } else {
        console.error('Failed to fetch candidates:', data.message);
      }
    } catch (error) {
      console.error('Error fetching candidates:', error);
    } finally {
      setLoading(false);
    }
  };

  // تطبيق الفلاتر
  useEffect(() => {
    let filtered = candidates.filter(candidate => {
      // فلتر نوع المجلس
      let councilTypeMatch = true;
      if (filters.councilType) {
        if (filters.councilType === 'نواب') {
          councilTypeMatch = candidate.candidateType.includes('نواب');
        } else if (filters.councilType === 'شيوخ') {
          councilTypeMatch = candidate.candidateType.includes('شيوخ');
        }
      }

      return (
        candidate.name.toLowerCase().includes(filters.name.toLowerCase()) &&
        (filters.gender === '' || candidate.gender === filters.gender) &&
        (filters.governorate === '' || candidate.governorate === filters.governorate) &&
        (filters.constituency === '' || candidate.constituency.includes(filters.constituency)) &&
        (filters.party === '' || candidate.party === filters.party) &&
        (filters.candidateType === '' || candidate.candidateType === filters.candidateType) &&
        councilTypeMatch
      );
    });
    
    setFilteredCandidates(filtered);
    setCurrentPage(1);
  }, [filters, candidates]);

  const handleFilterChange = (filterName: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [filterName]: value
    }));
  };

  const getCurrentPageCandidates = () => {
    const startIndex = (currentPage - 1) * candidatesPerPage;
    const endIndex = startIndex + candidatesPerPage;
    return filteredCandidates.slice(startIndex, endIndex);
  };

  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <span key={i} style={{ color: i <= rating ? '#ffd700' : '#ddd', fontSize: '16px' }}>
          ★
        </span>
      );
    }
    return stars;
  };

  if (loading) {
    return (
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <p>جاري تحميل البيانات...</p>
      </div>
    );
  }

  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '30px', color: '#2c3e50' }}>
        المرشحين للانتخابات
      </h1>

      {/* الفلاتر */}
      <div style={{ 
        backgroundColor: '#f8f9fa', 
        padding: '20px', 
        borderRadius: '8px', 
        marginBottom: '30px',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '15px'
      }}>
        <input
          type="text"
          placeholder="البحث بالاسم"
          value={filters.name}
          onChange={(e) => handleFilterChange('name', e.target.value)}
          style={{
            padding: '10px',
            border: '1px solid #ddd',
            borderRadius: '4px',
            fontSize: '14px'
          }}
        />

        <select
          value={filters.gender}
          onChange={(e) => handleFilterChange('gender', e.target.value)}
          style={{
            padding: '10px',
            border: '1px solid #ddd',
            borderRadius: '4px',
            fontSize: '14px'
          }}
        >
          <option value="">جميع الأنواع</option>
          <option value="ذكر">ذكر</option>
          <option value="أنثى">أنثى</option>
        </select>

        <select
          value={filters.candidateType}
          onChange={(e) => handleFilterChange('candidateType', e.target.value)}
          style={{
            padding: '10px',
            border: '1px solid #ddd',
            borderRadius: '4px',
            fontSize: '14px'
          }}
        >
          <option value="">جميع أنواع الترشح</option>
          <option value="مرشح نواب">مرشح نواب</option>
          <option value="مرشح شيوخ">مرشح شيوخ</option>
        </select>

        <select
          value={filters.councilType}
          onChange={(e) => handleFilterChange('councilType', e.target.value)}
          style={{
            padding: '10px',
            border: '1px solid #ddd',
            borderRadius: '4px',
            fontSize: '14px'
          }}
        >
          <option value="">جميع المجالس</option>
          <option value="نواب">مجلس النواب</option>
          <option value="شيوخ">مجلس الشيوخ</option>
        </select>

        <input
          type="text"
          placeholder="المحافظة"
          value={filters.governorate}
          onChange={(e) => handleFilterChange('governorate', e.target.value)}
          style={{
            padding: '10px',
            border: '1px solid #ddd',
            borderRadius: '4px',
            fontSize: '14px'
          }}
        />

        <input
          type="text"
          placeholder="الدائرة الانتخابية"
          value={filters.constituency}
          onChange={(e) => handleFilterChange('constituency', e.target.value)}
          style={{
            padding: '10px',
            border: '1px solid #ddd',
            borderRadius: '4px',
            fontSize: '14px'
          }}
        />

        <input
          type="text"
          placeholder="الحزب السياسي"
          value={filters.party}
          onChange={(e) => handleFilterChange('party', e.target.value)}
          style={{
            padding: '10px',
            border: '1px solid #ddd',
            borderRadius: '4px',
            fontSize: '14px'
          }}
        />
      </div>

      {/* عدد النتائج */}
      <p style={{ marginBottom: '20px', color: '#666' }}>
        عدد النتائج: {filteredCandidates.length} مرشح
      </p>

      {/* الكروت */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '20px',
        marginBottom: '30px'
      }}>
        {getCurrentPageCandidates().map((candidate) => (
          <div
            key={candidate.id}
            style={{
              backgroundColor: '#fff',
              border: '1px solid #e0e0e0',
              borderRadius: '12px',
              padding: '20px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              transition: 'transform 0.2s, box-shadow 0.2s',
              cursor: 'pointer'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-5px)';
              e.currentTarget.style.boxShadow = '0 4px 15px rgba(0,0,0,0.15)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
            }}
          >
            {/* صورة المرشح */}
            <div style={{
              width: '80px',
              height: '80px',
              borderRadius: '50%',
              backgroundColor: '#e9ecef',
              margin: '0 auto 15px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '24px',
              color: '#6c757d'
            }}>
              {candidate.image ? (
                <img 
                  src={candidate.image} 
                  alt={candidate.name}
                  style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }}
                />
              ) : (
                '👤'
              )}
            </div>

            {/* اسم المرشح */}
            <h3 style={{
              textAlign: 'center',
              marginBottom: '10px',
              color: '#2c3e50',
              fontSize: '18px',
              fontWeight: 'bold'
            }}>
              {candidate.name}
            </h3>

            {/* نوع الترشح */}
            <p style={{
              textAlign: 'center',
              marginBottom: '8px',
              color: '#dc3545',
              fontWeight: '600',
              fontSize: '14px'
            }}>
              {candidate.candidateType}
            </p>

            {/* المحافظة والدائرة */}
            <p style={{
              textAlign: 'center',
              marginBottom: '8px',
              color: '#666',
              fontSize: '14px'
            }}>
              {candidate.governorate} - {candidate.constituency}
            </p>

            {/* الحزب */}
            <p style={{
              textAlign: 'center',
              marginBottom: '8px',
              color: '#28a745',
              fontSize: '13px',
              fontWeight: '500'
            }}>
              {candidate.party}
            </p>

            {/* الرمز والرقم الانتخابي */}
            <div style={{
              display: 'flex',
              justifyContent: 'center',
              gap: '15px',
              marginBottom: '15px',
              fontSize: '12px',
              color: '#666'
            }}>
              <span>الرمز: {candidate.electoralSymbol}</span>
              <span>الرقم: {candidate.electoralNumber}</span>
            </div>

            {/* التقييم */}
            <div style={{ textAlign: 'center', marginBottom: '15px' }}>
              {renderStars(candidate.rating || 0)}
              <span style={{ marginLeft: '8px', color: '#666', fontSize: '14px' }}>
                ({candidate.rating?.toFixed(1) || '0.0'})
              </span>
            </div>

            {/* أزرار العمل */}
            <div style={{
              display: 'flex',
              gap: '10px',
              justifyContent: 'center'
            }}>
              <button
                style={{
                  backgroundColor: '#007bff',
                  color: 'white',
                  border: 'none',
                  padding: '8px 16px',
                  borderRadius: '6px',
                  fontSize: '12px',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#0056b3'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#007bff'}
              >
                إرسال رسالة
              </button>
              
              <Link href={`/candidates/${candidate.id}`}>
                <button
                  style={{
                    backgroundColor: '#28a745',
                    color: 'white',
                    border: 'none',
                    padding: '8px 16px',
                    borderRadius: '6px',
                    fontSize: '12px',
                    cursor: 'pointer',
                    transition: 'background-color 0.2s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#1e7e34'}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#28a745'}
                >
                  عرض التفاصيل
                </button>
              </Link>
            </div>
          </div>
        ))}
      </div>

      {/* الترقيم */}
      {totalPages > 1 && (
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          gap: '10px',
          marginTop: '30px'
        }}>
          <button
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            style={{
              padding: '8px 12px',
              border: '1px solid #ddd',
              borderRadius: '4px',
              backgroundColor: currentPage === 1 ? '#f8f9fa' : '#fff',
              cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
              color: currentPage === 1 ? '#6c757d' : '#007bff'
            }}
          >
            السابق
          </button>

          {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
            <button
              key={page}
              onClick={() => setCurrentPage(page)}
              style={{
                padding: '8px 12px',
                border: '1px solid #ddd',
                borderRadius: '4px',
                backgroundColor: currentPage === page ? '#007bff' : '#fff',
                color: currentPage === page ? '#fff' : '#007bff',
                cursor: 'pointer'
              }}
            >
              {page}
            </button>
          ))}

          <button
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            style={{
              padding: '8px 12px',
              border: '1px solid #ddd',
              borderRadius: '4px',
              backgroundColor: currentPage === totalPages ? '#f8f9fa' : '#fff',
              cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
              color: currentPage === totalPages ? '#6c757d' : '#007bff'
            }}
          >
            التالي
          </button>
        </div>
      )}

      {/* رسالة عدم وجود نتائج */}
      {filteredCandidates.length === 0 && (
        <div style={{
          textAlign: 'center',
          padding: '50px',
          color: '#666'
        }}>
          <p>لا توجد نتائج تطابق معايير البحث</p>
        </div>
      )}
    </div>
  );
}
