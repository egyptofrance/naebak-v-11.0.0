# 🏛️ منصة نائبك - Naebak Platform

منصة التواصل المباشر مع النواب والمرشحين في مصر

## 🚀 النشر السريع على Vercel

### 1. متغيرات البيئة المطلوبة
```
NEXT_PUBLIC_SUPABASE_URL=https://njjhfhhvivxkslvmnogs.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5qamhmaGh2aXZ4a3Nsdm1ub2dzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTkxNDA0NTIsImV4cCI6MjA3NDcxNjQ1Mn0.5lEf7qLpWeuYvEctwzYDdGpTuoMeCB04CE6gIE0qPas
NEXT_PUBLIC_AUTH_API_URL=https://naebak-auth-service-822351033701.us-central1.run.app
```

### 2. خطوات النشر
1. اربط هذا المستودع بـ Vercel
2. أضف متغيرات البيئة أعلاه
3. اضغط Deploy

## 🛠️ التطوير المحلي

```bash
# تثبيت التبعيات
npm install

# تشغيل الخادم المحلي
npm run dev

# بناء المشروع
npm run build
```

## 📋 الميزات

- ✅ تسجيل المواطنين والمرشحين وأعضاء البرلمان
- ✅ نظام مصادقة متقدم مع NextAuth.js
- ✅ قاعدة بيانات Supabase
- ✅ واجهة مستخدم عربية متجاوبة
- ✅ نظام إدارة الشكاوى والمقترحات
- ✅ متابعة أداء النواب والمرشحين

## 🔧 التقنيات المستخدمة

- **Frontend:** Next.js 15 + TypeScript
- **Styling:** Bootstrap + CSS مخصص
- **Database:** Supabase (PostgreSQL)
- **Authentication:** NextAuth.js
- **Deployment:** Vercel

---

**آخر تحديث:** 30 سبتمبر 2025  
**الحالة:** 🟢 جاهز للنشر
