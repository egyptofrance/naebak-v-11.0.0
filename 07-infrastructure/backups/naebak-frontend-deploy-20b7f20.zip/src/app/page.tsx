import { createClient } from '@/_lib/supabase-client';
import Banner from '@/components/Banner'; 
import NewsTicker from '@/components/NewsTicker';

// هذه الدالة مسؤولة عن جلب البيانات من قاعدة البيانات
async function getSiteConfig() {
  // تأكد من أن هذه هي الطريقة الصحيحة لإنشاء العميل
  const supabase = createClient(); 
  
  // نقوم بجلب النص من جدول site_config
  const { data, error } = await supabase
    .from('site_config')
    .select('news_ticker_text')
    .single(); // .single() لجلب صف واحد فقط

  // في حالة حدوث خطأ في الاتصال، سنعرفه من هنا
  if (error) {
    console.error('Error fetching site config:', error);
    return null;
  }

  return data;
}

export default async function HomePage() {
  // نقوم باستدعاء الدالة لجلب البيانات
  const config = await getSiteConfig();
  console.log('Fetched Supabase Config:', config);


  return (
    <>
      {/* أولاً: البانر */}
      <Banner />

      {/* ثانياً: شريط الأخبار، تحت البانر */}
      {/* نتأكد من وجود البيانات قبل عرض المكون */}
      {config && config.news_ticker_text ? (
        <NewsTicker text={config.news_ticker_text} />
      ) : (
        // يمكنك وضع رسالة هنا في حالة عدم وجود نص، أو لا تضع شيئًا
        // <p>لا يوجد أخبار حاليًا</p> 
        null
      )}

      {/* باقي محتوى الصفحة */}
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-4xl font-bold mb-4">مرحبًا بك في نائبك دوت كوم</h1>
        <p className="text-xl text-gray-500">
          المنصة التي تصلك مباشرة بممثليك
        </p>
      </div>
    </>
  );
}
