# 🚀 دليل النشر اليدوي على Vercel

## ✅ المشروع جاهز للنشر!

تم تحديث جميع APIs لتستخدم **Supabase** بدلاً من Google Run.

## 📋 خطوات النشر (5 دقائق):

### 1. اذهب إلى Vercel
- افتح [vercel.com](https://vercel.com)
- اضغط "Sign Up" أو "Log In"
- سجل الدخول بحساب GitHub

### 2. استيراد المشروع
- اضغط "Add New..." ثم "Project"
- اختر "Import Git Repository"
- ابحث عن `naebak-frontend-deploy`
- اضغط "Import"

### 3. إعداد متغيرات البيئة
في صفحة الإعداد، أضف هذه المتغيرات:

```
NEXT_PUBLIC_SUPABASE_URL
https://njjhfhhvivxkslvmnogs.supabase.co

NEXT_PUBLIC_SUPABASE_ANON_KEY
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5qamhmaGh2aXZ4a3Nsdm1ub2dzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTkxNDA0NTIsImV4cCI6MjA3NDcxNjQ1Mn0.5lEf7qLpWeuYvEctwzYDdGpTuoMeCB04CE6gIE0qPas

NEXTAUTH_URL
https://naebak.vercel.app

NEXTAUTH_SECRET
kdlsgarharg%$%^FghgfhSFGHSFH^$%^%@$^@$DFssfsFGr%##RGWRHR^&#SFHSsfggsgT45sH
```

### 4. النشر
- اضغط "Deploy"
- انتظر 2-3 دقائق
- ✅ تم! موقعك جاهز

## 🔧 التحديثات المطبقة:

### ✅ APIs محدثة لـ Supabase:
- **NextAuth:** يستخدم Supabase Auth
- **Registration:** يحفظ في Supabase Database  
- **Governorates:** يقرأ من Supabase أو fallback محلي
- **Users:** يتعامل مع Supabase Users table

### ✅ إعدادات محسنة:
- **vercel.json:** محدث للمتغيرات الجديدة
- **Environment:** ملفات البيئة محدثة
- **Build:** تم اختبار البناء بنجاح

## 🎯 ما بعد النشر:

1. **اختبر الموقع:** تأكد من عمل التسجيل والدخول
2. **تحديث DNS:** إذا كان لديك دومين مخصص
3. **مراقبة الأداء:** استخدم Vercel Analytics

## 🔗 روابط مهمة:

- **المستودع:** https://github.com/egyptofrance/naebak-frontend-deploy
- **Vercel Dashboard:** https://vercel.com/dashboard
- **Supabase Dashboard:** https://supabase.com/dashboard

---

**الحالة:** 🟢 جاهز للنشر الفوري  
**آخر تحديث:** 30 سبتمبر 2025
