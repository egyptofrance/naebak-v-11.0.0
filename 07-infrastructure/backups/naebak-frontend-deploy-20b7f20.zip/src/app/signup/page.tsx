'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation'; // 1. Import the router
import { createClient } from '@/_lib/supabase-client'; // 2. Import the Supabase client

export default function SignupPage() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [userType, setUserType] = useState('citizen');
  
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const router = useRouter();
  const supabase = createClient();

  // 3. This is the updated signup handler function
  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (password !== confirmPassword) {
      setError('كلمتا المرور غير متطابقتين!');
      return;
    }
    
    setLoading(true);

    // Use Supabase to sign up a new user
    const { data, error } = await supabase.auth.signUp({
      email: email,
      password: password,
      options: {
        // We pass the extra data here
        data: {
          full_name: fullName,
          user_type: userType,
        },
      },
    });

    if (error) {
      console.error('Supabase signup error:', error.message);
      if (error.message.includes('User already registered')) {
        setError('هذا البريد الإلكتروني مسجل بالفعل. يرجى تسجيل الدخول.');
      } else {
        setError('حدث خطأ ما. يرجى المحاولة مرة أخرى.');
      }
      setLoading(false);
    } else if (data.user) {
        // By default, Supabase requires email confirmation.
        setSuccessMessage(
            'تم إنشاء حسابك بنجاح! لقد أرسلنا رابط تفعيل إلى بريدك الإلكتروني. يرجى الضغط عليه لتفعيل حسابك ثم تسجيل الدخول.'
        );
        setLoading(false);
    }
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-lg-6 col-md-8">
          <div className="card shadow-lg border-0 rounded-lg">
            <div className="card-header text-center py-4" style={{backgroundColor: '#004705'}}>
              <h2 className="fw-bold mb-0 text-white">إنشاء حساب جديد</h2>
              <p className="text-white-50 mb-0 mt-2">انضم إلى منصة نائبك الآن</p>
            </div>
            <div className="card-body p-5">
              {/* Show success or error messages */}
              {error && <div className="alert alert-danger">{error}</div>}
              {successMessage && <div className="alert alert-success">{successMessage}</div>}

              {/* Hide the form after successful signup */}
              {!successMessage && (
                <form onSubmit={handleSignup}>
                  <div className="form-floating mb-3">
                    <input id="fullName" type="text" className="form-control" placeholder="الاسم الكامل" value={fullName} onChange={(e) => setFullName(e.target.value)} required disabled={loading} />
                    <label htmlFor="fullName">الاسم الكامل</label>
                  </div>
                  <div className="form-floating mb-3">
                    <input id="email" type="email" className="form-control" placeholder="البريد الإلكتروني" value={email} onChange={(e) => setEmail(e.target.value)} required disabled={loading} />
                    <label htmlFor="email">البريد الإلكتروني</label>
                  </div>
                  <div className="form-floating mb-3">
                    <input id="password" type="password" className="form-control" placeholder="كلمة المرور" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} disabled={loading} />
                    <label htmlFor="password">كلمة المرور (6 أحرف على الأقل)</label>
                  </div>
                  <div className="form-floating mb-4">
                    <input id="confirmPassword" type="password" className="form-control" placeholder="تأكيد كلمة المرور" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required disabled={loading} />
                    <label htmlFor="confirmPassword">تأكيد كلمة المرور</label>
                  </div>
                  <div className="mb-4">
                      <label className="form-label fw-bold" style={{color: '#004705'}}>أنا أسجل بصفتي:</label>
                      <select className="form-select" value={userType} onChange={(e) => setUserType(e.target.value)} disabled={loading}>
                          <option value="citizen">مواطن</option>
                          <option value="candidate_mp">مرشح لمجلس النواب</option>
                          <option value="candidate_senate">مرشح لمجلس الشيوخ</option>
                      </select>
                      <div className="form-text">ملاحظة: سيتم مراجعة طلبات المرشحين من قبل الإدارة.</div>
                  </div>
                  <div className="d-grid">
                    <button type="submit" className="btn btn-lg text-white fw-bold" style={{backgroundColor: '#004705'}} disabled={loading}>
                      {loading ? 'جاري إنشاء الحساب...' : 'إنشاء الحساب'}
                    </button>
                  </div>
                </form>
              )}
            </div>
            <div className="card-footer text-center py-3">
              <div className="small">
                لديك حساب بالفعل؟{' '}
                <Link href="/login" className="fw-bold" style={{color: '#004705'}}>
                  قم بتسجيل الدخول
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
