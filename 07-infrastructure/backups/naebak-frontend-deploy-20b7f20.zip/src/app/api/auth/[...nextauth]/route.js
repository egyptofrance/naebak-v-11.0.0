import NextAuth from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
)

const handler = NextAuth({
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials) {
        try {
          // Use Supabase auth instead of external API
          const { data, error } = await supabase.auth.signInWithPassword({
            email: credentials.email,
            password: credentials.password,
          })

          if (error) {
            console.error('Supabase auth error:', error)
            return null
          }

          if (data.user) {
            // Get additional user data from our users table
            const { data: userData, error: userError } = await supabase
              .from('users')
              .select('*')
              .eq('email', credentials.email)
              .single()

            if (userError) {
              console.error('User data error:', userError)
              return null
            }

            return {
              id: data.user.id,
              email: data.user.email,
              name: userData.full_name || userData.first_name + ' ' + userData.last_name,
              user_type: userData.user_type,
              phone_number: userData.phone_number,
              governorate_id: userData.governorate_id,
              access_token: data.session?.access_token
            }
          }
          return null
        } catch (error) {
          console.error('Auth error:', error)
          return null
        }
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.user_type = user.user_type
        token.phone_number = user.phone_number
        token.governorate_id = user.governorate_id
        token.access_token = user.access_token
      }
      return token
    },
    async session({ session, token }) {
      session.user.user_type = token.user_type
      session.user.phone_number = token.phone_number
      session.user.governorate_id = token.governorate_id
      session.access_token = token.access_token
      return session
    }
  },
  pages: {
    signIn: '/',
    signUp: '/',
  },
  session: {
    strategy: 'jwt',
  },
  secret: process.env.NEXTAUTH_SECRET,
})

export { handler as GET, handler as POST }
