'use client';

import Header from './Header';
import Banner from './Banner';
import NewsTicker from './NewsTicker';
import Footer from './Footer';

interface LayoutProps {
  children: React.ReactNode;
  showBanner?: boolean;
}

export default function Layout({ children, showBanner = true }: LayoutProps) {
  return (
    <div className="min-vh-100 d-flex flex-column">
      {/* Header - يظهر في جميع الصفحات */}
      <Header />
      
      {/* Banner - يظهر في الصفحة الرئيسية فقط أو حسب الحاجة */}
      {showBanner && <Banner />}
      
      {/* News Ticker - يظهر في جميع الصفحات تحت البانر */}
      <NewsTicker text="أهلاً بكم في منصة نائبك - المنصة الرسمية للتواصل مع النواب والمرشحين" />
      
      {/* المحتوى الرئيسي */}
      <main className="flex-grow-1">
        {children}
      </main>
      
      {/* Footer - يظهر في جميع الصفحات */}
      <Footer />
    </div>
  );
}
