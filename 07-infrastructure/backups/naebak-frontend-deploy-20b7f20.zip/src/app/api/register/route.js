import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
)

export async function POST(request) {
  try {
    const body = await request.json()
    const userType = body.userType || 'citizen';
    
    // Define required fields based on user type
    let requiredFields = ['name', 'email', 'password', 'phone'];
    
    if (userType === 'citizen') {
      requiredFields = ['firstName', 'lastName', 'nationalId', 'email', 'password', 'phone', 'governorate', 'city', 'gender'];
    } else if (userType === 'member') {
      requiredFields = ['name', 'email', 'password', 'phone', 'whatsapp', 'position', 'governorate', 'district'];
    } else if (userType === 'candidate') {
      requiredFields = ['name', 'email', 'password', 'phone', 'whatsapp', 'candidateType', 'governorate', 'district', 'electoralSymbol', 'electoralNumber'];
    }
    
    const missingFields = requiredFields.filter(field => !body[field]);
    
    if (missingFields.length > 0) {
      return NextResponse.json({
        success: false,
        message: 'بعض الحقول المطلوبة مفقودة',
        errors: missingFields.reduce((acc, field) => {
          acc[field] = 'هذا الحقل مطلوب';
          return acc;
        }, {})
      }, { status: 400 });
    }

    // Create user in Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: body.email,
      password: body.password,
    })

    if (authError) {
      console.error('Supabase auth error:', authError)
      return NextResponse.json({
        success: false,
        message: 'خطأ في إنشاء الحساب',
        errors: { email: 'البريد الإلكتروني قد يكون مستخدم بالفعل' }
      }, { status: 400 })
    }

    // Prepare user data for database
    let userData = {
      id: authData.user.id,
      email: body.email,
      user_type: userType,
      created_at: new Date().toISOString()
    };

    if (userType === 'citizen') {
      userData = {
        ...userData,
        first_name: body.firstName,
        last_name: body.lastName,
        full_name: `${body.firstName} ${body.lastName}`,
        phone_number: body.phone,
        whatsapp_number: body.whatsapp || body.phone,
        national_id: body.nationalId,
        birth_date: body.birthDate,
        gender: body.gender,
        governorate_id: parseInt(body.governorate),
        city: body.city,
        center: body.center || '',
        district: body.district || '',
        village: body.village || '',
        street: body.street || '',
        house_number: body.houseNumber || ''
      };
    } else if (userType === 'member') {
      userData = {
        ...userData,
        full_name: body.name,
        phone_number: body.phone,
        whatsapp_number: body.whatsapp,
        position: body.position,
        governorate_id: parseInt(body.governorate),
        constituency: body.district,
        committee: body.committee || '',
        membership_date: body.membershipDate || new Date().toISOString().split('T')[0],
        biography: body.biography || '',
        party: body.party || 'مستقل'
      };
    } else if (userType === 'candidate') {
      userData = {
        ...userData,
        full_name: body.name,
        phone_number: body.phone,
        whatsapp_number: body.whatsapp,
        candidate_type: body.candidateType,
        governorate_id: parseInt(body.governorate),
        constituency: body.district,
        electoral_symbol: body.electoralSymbol,
        electoral_number: body.electoralNumber,
        profession: body.profession || '',
        biography: body.biography || '',
        electoral_program: body.electoralProgram || '',
        party: body.party || 'مستقل'
      };
    }

    // Insert user data into our users table
    const { data: dbData, error: dbError } = await supabase
      .from('users')
      .insert([userData])
      .select()
      .single()

    if (dbError) {
      console.error('Database error:', dbError)
      // If database insert fails, we should clean up the auth user
      await supabase.auth.admin.deleteUser(authData.user.id)
      
      return NextResponse.json({
        success: false,
        message: 'خطأ في حفظ بيانات المستخدم',
        errors: { general: 'حدث خطأ أثناء حفظ البيانات' }
      }, { status: 500 })
    }

    // Determine redirect URL based on user type
    let redirectUrl = '/citizen/dashboard';
    if (userType === 'member') {
      redirectUrl = '/member/dashboard';
    } else if (userType === 'candidate') {
      redirectUrl = '/candidate/dashboard';
    }

    return NextResponse.json({
      success: true,
      message: 'تم إنشاء الحساب بنجاح',
      user: dbData,
      redirect: redirectUrl
    })

  } catch (error) {
    console.error('Registration error:', error)
    
    return NextResponse.json({
      success: false,
      message: 'حدث خطأ في الخادم. يرجى المحاولة مرة أخرى.',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    }, { status: 500 })
  }
}
