import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
)

export async function GET() {
  try {
    // Try to get governorates from Supabase
    const { data, error } = await supabase
      .from('governorates')
      .select('*')
      .order('name')

    if (error) {
      console.error('Supabase error:', error)
      // Fallback to local data
      const fallbackData = {
        governorates: [
          { id: 1, name: 'القاهرة' },
          { id: 2, name: 'الجيزة' },
          { id: 3, name: 'الإسكندرية' },
          { id: 4, name: 'الدقهلية' },
          { id: 5, name: 'الشرقية' },
          { id: 6, name: 'القليوبية' },
          { id: 7, name: 'كفر الشيخ' },
          { id: 8, name: 'الغربية' },
          { id: 9, name: 'المنوفية' },
          { id: 10, name: 'البحيرة' },
          { id: 11, name: 'الإسماعيلية' },
          { id: 12, name: 'بورسعيد' },
          { id: 13, name: 'السويس' },
          { id: 14, name: 'المنيا' },
          { id: 15, name: 'بني سويف' },
          { id: 16, name: 'الفيوم' },
          { id: 17, name: 'أسيوط' },
          { id: 18, name: 'سوهاج' },
          { id: 19, name: 'قنا' },
          { id: 20, name: 'الأقصر' },
          { id: 21, name: 'أسوان' },
          { id: 22, name: 'البحر الأحمر' },
          { id: 23, name: 'الوادي الجديد' },
          { id: 24, name: 'مطروح' },
          { id: 25, name: 'شمال سيناء' },
          { id: 26, name: 'جنوب سيناء' },
          { id: 27, name: 'دمياط' }
        ]
      }
      return NextResponse.json(fallbackData, { status: 200 })
    }

    return NextResponse.json({
      success: true,
      governorates: data
    })

  } catch (error) {
    console.error('Governorates API error:', error)
    
    // Fallback to local data
    const fallbackData = {
      governorates: [
        { id: 1, name: 'القاهرة' },
        { id: 2, name: 'الجيزة' },
        { id: 3, name: 'الإسكندرية' },
        { id: 4, name: 'الدقهلية' },
        { id: 5, name: 'الشرقية' },
        { id: 6, name: 'القليوبية' },
        { id: 7, name: 'كفر الشيخ' },
        { id: 8, name: 'الغربية' },
        { id: 9, name: 'المنوفية' },
        { id: 10, name: 'البحيرة' },
        { id: 11, name: 'الإسماعيلية' },
        { id: 12, name: 'بورسعيد' },
        { id: 13, name: 'السويس' },
        { id: 14, name: 'المنيا' },
        { id: 15, name: 'بني سويف' },
        { id: 16, name: 'الفيوم' },
        { id: 17, name: 'أسيوط' },
        { id: 18, name: 'سوهاج' },
        { id: 19, name: 'قنا' },
        { id: 20, name: 'الأقصر' },
        { id: 21, name: 'أسوان' },
        { id: 22, name: 'البحر الأحمر' },
        { id: 23, name: 'الوادي الجديد' },
        { id: 24, name: 'مطروح' },
        { id: 25, name: 'شمال سيناء' },
        { id: 26, name: 'جنوب سيناء' },
        { id: 27, name: 'دمياط' }
      ]
    }
    return NextResponse.json(fallbackData, { status: 200 })
  }
}
